
import 'package:flutter/material.dart';
import 'package:tflite_flutter/tflite_flutter.dart';

void main() => runApp(AviatorApp());

class AviatorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: PredictionScreen(),
    );
  }
}

class PredictionScreen extends StatefulWidget {
  @override
  _PredictionScreenState createState() => _PredictionScreenState();
}

class _PredictionScreenState extends State<PredictionScreen> {
  late Interpreter _interpreter;
  List<double> _inputData = List.filled(50, 0.0);
  double _prediction = 0.0;

  @override
  void initState() {
    super.initState();
    loadModel();
  }

  Future<void> loadModel() async {
    _interpreter = await Interpreter.fromAsset('aviator_predictor.tflite');
  }

  void predictNext() {
    var input = _inputData.reshape([1, 50, 1]);
    var output = List.filled(1, 0.0).reshape([1, 1]);
    _interpreter.run(input, output);
    setState(() {
      _prediction = output[0][0];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Aviator Predictor')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Next Prediction: $_prediction'),
            ElevatedButton(
              onPressed: predictNext,
              child: Text('Predict'),
            ),
          ],
        ),
      ),
    );
  }
}
